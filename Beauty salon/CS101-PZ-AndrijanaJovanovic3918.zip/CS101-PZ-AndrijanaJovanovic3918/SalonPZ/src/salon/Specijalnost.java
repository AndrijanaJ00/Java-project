package salon;

public enum Specijalnost {
    frizer, sminker;
}

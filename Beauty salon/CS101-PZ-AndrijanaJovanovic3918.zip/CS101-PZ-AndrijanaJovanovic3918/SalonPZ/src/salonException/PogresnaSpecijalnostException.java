package salonException;

public class PogresnaSpecijalnostException extends Exception{

    public PogresnaSpecijalnostException(String string) {
        super(string);
    } 
}